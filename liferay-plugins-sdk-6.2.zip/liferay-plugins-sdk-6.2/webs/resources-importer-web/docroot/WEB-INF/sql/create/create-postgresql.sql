drop database lportal;
create database lportal encoding = 'UNICODE';
\c lportal;





