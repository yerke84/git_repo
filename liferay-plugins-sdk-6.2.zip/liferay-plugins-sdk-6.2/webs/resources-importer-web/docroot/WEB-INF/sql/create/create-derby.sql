drop database lportal;
create database lportal;
connect to lportal;




